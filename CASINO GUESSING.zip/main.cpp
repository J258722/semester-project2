// AUTHOR:
//INDEX NUMBER: UEB3229022
//EMAIL:joycedogfobaare@gmail.com

#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

int main() {
    srand(time(0)); // Seed the random number generator with current time
    
    int casinoNumber = rand() % 100 + 1; // Generate a random number between 1 and 100
    int guess;
    int attempts = 0;
    
    cout << "Welcome to the Casino Number Guessing Game!" << endl;
    cout << "Try to guess the casino's number between 1 and 100." << endl;
    
    do {
        cout << "Enter your guess: ";
        cin >> guess;
        
        attempts++;
        
        if (guess > casinoNumber) {
            cout << "Too high! Try again." << endl;
        } else if (guess < casinoNumber) {
            cout << "Too low! Try again." << endl;
        } else {
            cout << "Congratulations! You guessed the casino's number in " << attempts << " attempts." << endl;
        }
    } while (guess != casinoNumber);
    
    return 0;
}
 

